import "./home.css";

const Home = () => {
  return (
    <div className="home-page">
      <div className="top-banner">
        <div className="top-banner-text">
          <h1>Electronic</h1>
          <h2>Electronics for all at prices you can afford!</h2>
        </div>
        <img src="/images/electronic home.jpeg" alt="electronics" />
      </div>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Illum,
        doloremque voluptate necessitatibus non deleniti fugit illo nesciunt
        dolor fugiat quam libero corrupti, magnam debitis odio deserunt tenetur
        est dicta. Accusantium?
      </p>
    </div>
  );
};

export default Home;
