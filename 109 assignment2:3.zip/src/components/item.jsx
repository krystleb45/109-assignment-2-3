import React, { useState } from "react";

import "./item.css";
import QuantityPicker from "./quantityPicker";

const Item = (props) => {
  //state
  const [quantity, setQuantity] = useState(props.data.minimum || 1);

  //function

  const handleAdd = () => {
    console.log("Adding item to cart");
  };

  const onQuantityChange = (quantity) => {
    console.log("new qnty", quantity);
    setQuantity(quantity);
  };

  const getTotal = () => {
    let total = props.data.price * quantity;
    return total.toFixed(2);
  };
  //return
  return (
    <div className="item">
      <img src={"/images/" + props.data.image} alt="product" />

      <h5>{props.data.title || "no title"}</h5>

      <label className="price">Price $ {props.data.price.toFixed(2)}</label>
      <hr />
      <label className="total">Total $ {getTotal()}</label>

      <div className="controls">
        <QuantityPicker
          minimum={props.data.minimum || 1}
          onChange={onQuantityChange}
        />

        <button onClick={handleAdd} className="btn btn-sm btn-dark">
          {" "}
          <i className="fa fa-cart-plus" aria-hidden="true"></i>
        </button>
      </div>
    </div>
  );
};

export default Item;
